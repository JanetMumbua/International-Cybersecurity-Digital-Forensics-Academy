# AICS-202 Adversarial Machine Learning – Submission Package

**Student:** Janet Mumbua Kyanzi  **Registration No.:** 2026/AICDF/16753  **Programme:** AI-Driven Cybersecurity and Digital Forensics (AICDF)  **Date:** 16 November 2026

## Contents
| Path | Description |
|---|---|
| `AICS202_Final_Report.pdf` | Integrated technical report |
| `notebooks/AICS202_Lab01_Baseline_Threat_Model.ipynb` | Executed Lab 01 + student extension (E01) |
| `notebooks/AICS202_Lab02_FGSM_Evasion.ipynb` | Executed Lab 02 + extended ε sweep, PGD, ASR (E02) |
| `notebooks/AICS202_Lab03_Poisoning_Data_Integrity.ipynb` | Executed Lab 03 + 5-seed repeats, targeted flip, kNN audit (E03) |
| `notebooks/AICS202_Lab04_Robustness_Defences.ipynb` | Executed Lab 04 + adaptive vs transfer, PGD sweep, budget sensitivity, weight-norm analysis (E04) |
| `results/` | Exported charts (E01–E04 PNG) and metrics (`lab01–04_metrics.json`) |
| `requirements.txt` | Python dependencies |

Original ICDFA cells are unchanged; additions are the cells headed **"Student extension"** at the end of each notebook.

## Test environment (recorded run)
- OS: Linux x86_64
- Python 3.13.18 · NumPy 2.5.3 · scikit-learn 1.9.1 · Matplotlib 3.11.2 · Jupyter (nbclient/ipykernel)
- CPU only; no GPU, no network access required after installation

## Random seeds
| Use | Seed |
|---|---|
| Train/test split, model, `np.random` | 42 |
| Lab 03 notebook corruption | 2026 |
| Lab 03 repeated trials | 2026, 1, 2, 3, 4 |
| Lab 03 targeted 3→8 selection | 7 |
| PGD random start | 42 |

## Run commands
```bash
cd notebooks
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
python -m pip install -r ../requirements.txt
python -m notebook
# Open each notebook in order (Lab01 → Lab04) and choose Kernel → Restart & Run All
```
Headless alternative:
```bash
jupyter nbconvert --to notebook --execute --inplace notebooks/*.ipynb
```
Charts and JSON metrics are written to `results/`. Compare them with the tables in the report.

## Safety
Only the bundled scikit-learn digits dataset and locally trained models were used. No external, production or third-party system was tested.
